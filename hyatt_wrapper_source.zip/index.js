/**
 * Responds to any HTTP request.
 *
 * @param {!express:Request} req HTTP request context.
 * @param {!express:Response} res HTTP response context.
 */
const express = require('express');
const app = express();
var requestify = require('requestify');
var xmlparser = require('express-xml-bodyparser');
var parser = require('fast-xml-parser');

// function makeRequest(uri, body){
  
// }


app.get('/', function(req,res) {
  var healthcheck = {
    uptime: process.uptime(),
    message: 'UP',
    timestamp: Date.now()
  };
  try {
    res.send(healthcheck);
  } catch (e) {
    healthcheck.message = e;
    res.status(503).send(healthcheck);
  }
});


app.use((req, res, next) => {
    console.log(`${req.method} ${req.originalUrl} [STARTED]`)
    const start = process.hrtime()
    res.on('finish', () => {
        const durationInMilliseconds = getDurationInMilliseconds (start)
        console.log(`${req.method} ${req.originalUrl} [FINISHED] ${durationInMilliseconds.toLocaleString()} s`)
    })
    res.on('close', () => {
        const durationInMilliseconds = getDurationInMilliseconds (start)
        console.log(`${req.method} ${req.originalUrl} [CLOSED] ${durationInMilliseconds.toLocaleString()} s`)
    })
    next()
})

app.post('/getPropertyStatus', function(req,res,next) {
  var operation = 'http://cac.synergymms.com/CACWebServices/cacj.asmx';
  // var operation = 'https://run.mocky.io/v3/c4c0cdbd-e728-4b81-9035-e0c104467656';
  console.log(operation);
  console.log("::::::::Query Body::::::::")
  var query_body = req.rawBody;
  var text_body = req.rawBody.toString()
  console.log(query_body)
  console.log(text_body);
  try {
    var API_OPTIONS = {
    headers: {
      'Content-Type': 'application/soap+xml',
      },
        dataType: "xml"
      };
    requestify.post(operation,query_body,API_OPTIONS).then(function(response){
      console.log("::::::::PRIOR TO PROCESSING RESPONSE:::::::::");
      console.log(response);
      var filter_body = response.body;
      console.log(filter_body);
      stripped = filter_body.replace(/(soap:)/g, "Soap");
      stripped = stripped.replace(/(xmlns:[\S]*")/g, "");
      stripped = stripped.replace(/(xmlns="[\S]*"[>])/g,">");
      console.log("MODIFIED RESPONSE:");
      res.send(stripped);
      // else {
      //   console.log('SOAP response was not valid XML');
      //   res.status(422).send('SOAP response was not valid XML')
      //   // return 'SOAP response was not valid XML';
      // }
        
    });
    // res.send('FILTER TESTING');
  }
  catch (e){
    console.log("Failed")
    // return e; 
    res.status(503).send(e);
  }
});

app.post('/getConnectCode', function(req,res,next) {
  var operation = 'https://awsohqadevweb1smms.synergymms.com/WebServices/vendor.asmx';
  // var operation = 'https://run.mocky.io/v3/c4c0cdbd-e728-4b81-9035-e0c104467656';
  console.log(operation);
  console.log("::::::::Query Body::::::::")
  var query_body = req.rawBody;
  console.log(query_body)
  var text_body = req.rawBody.toString()
  console.log(text_body);
  try {
    var API_OPTIONS = {
    headers: {
      'Content-Type': 'text/xml',
      },
        dataType: "xml"
      };
    requestify.post(operation,query_body,API_OPTIONS).then(function(response){
      console.log("::::::::PRIOR TO PROCESSING RESPONSE:::::::::");
      console.log(response);
      var filter_body = response.body;
      console.log(filter_body);
      stripped = filter_body.replace(/(soap:)/g, "Soap");
      stripped = stripped.replace(/( xmlns:[\S]*")/g, "");
      stripped = stripped.replace(/( xmlns="[\S]*"[>])/g,">"); 
      console.log("MODIFIED RESPONSE:");
      res.send(stripped);
      // else {
      //   console.log('SOAP response was not valid XML');
      //   res.status(422).send('SOAP response was not valid XML')
      //   // return 'SOAP response was not valid XML';
      // }
        
    });
    // res.send('FILTER TESTING');
  }
  catch (e){
    console.log("Failed")
    // return e; 
    res.status(503).send(e);
  }
});

app.post('/synergyMMS', function(req,res,next) {
  var operation = 'https://awsohqadevweb1smms.synergymms.com/WebServices/vendor.asmx';
  // var operation = 'https://run.mocky.io/v3/c4c0cdbd-e728-4b81-9035-e0c104467656';
  console.log(operation);
  console.log("::::::::Query Body::::::::")
  var query_body = req.rawBody;
  console.log(query_body)
  var text_body = req.rawBody.toString()
  console.log(text_body);
  try {
    var API_OPTIONS = {
    headers: {
      'Content-Type': 'text/xml',
      },
        dataType: "xml"
      };
    requestify.post(operation,query_body,API_OPTIONS).then(function(response){
      console.log("::::::::PRIOR TO PROCESSING RESPONSE:::::::::");
      console.log(response);
      var filter_body = response.body;
      console.log(filter_body);
      stripped = filter_body.replace(/(soap:)/g, "Soap");
      stripped = stripped.replace(/( xmlns:[\S]*")/g, "");
      stripped = stripped.replace(/( xmlns="[\S]*"[>])/g,">"); 
      stripped = stripped.replace(/([\D]:[\D])/g,"");
      stripped = stripped.replace(/( [\S]+=[\S]+")/g,"");
      stripped = stripped.replace(/([<][?][x][m][l][?][>])/g,'<?xml version="1.0" encoding="utf-8"?>');
      stripped = stripped.replace(/(<xlement \/>)/g,'');  
      console.log("MODIFIED RESPONSE:");
      res.send(stripped);
      // else {
      //   console.log('SOAP response was not valid XML');
      //   res.status(422).send('SOAP response was not valid XML')
      //   // return 'SOAP response was not valid XML';
      // }
        
    });
    // res.send('FILTER TESTING');
  }
  catch (e){
    console.log("Failed")
    // return e; 
    res.status(503).send(e);
  }
});

app.post('/getDisconnect', function(req,res,next) {
  var operation = 'https://awsohqadevweb1smms.synergymms.com/WebServices/vendor.asmx?op=Disconnect';
  // var operation = 'https://run.mocky.io/v3/c4c0cdbd-e728-4b81-9035-e0c104467656';
  console.log(operation);
  console.log("::::::::Query Body::::::::")
  var query_body = req.rawBody;
  console.log(query_body)
  var text_body = req.rawBody.toString()
  console.log(text_body);
  try {
    var API_OPTIONS = {
    headers: {
      'Content-Type': 'text/xml',
      },
        dataType: "xml"
      };
    requestify.post(operation,query_body,API_OPTIONS).then(function(response){
      console.log("::::::::PRIOR TO PROCESSING RESPONSE:::::::::");
      console.log(response);
      var filter_body = response.body;
      console.log(filter_body);
      stripped = filter_body.replace(/(soap:)/g, "Soap");
      stripped = stripped.replace(/( xmlns:[\S]*")/g, "");
      stripped = stripped.replace(/( xmlns="[\S]*"[>])/g,">"); 
      stripped = stripped.replace(/([\D]:[\D])/g,"");
      stripped = stripped.replace(/( [\S]+=[\S]+")/g,"");
      stripped = stripped.replace(/([<][?][x][m][l][?][>])/g,'<?xml version="1.0" encoding="utf-8"?>');  
      console.log("MODIFIED RESPONSE:");
      res.send(stripped);
      // else {
      //   console.log('SOAP response was not valid XML');
      //   res.status(422).send('SOAP response was not valid XML')
      //   // return 'SOAP response was not valid XML';
      // }
        
    });
    // res.send('FILTER TESTING');
  }
  catch (e){
    console.log("Failed")
    // return e; 
    res.status(503).send(e);
  }
});
module.exports = {
  app
}
